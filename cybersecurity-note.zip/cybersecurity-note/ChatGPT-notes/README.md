# Note:
- The reason why this repo is empty.... due to misusing Ai for cybersecurity
- in future I'm planning to create some note and how to use Ai for cybersecurity purposes...!
