
# VMware Workstation 17 Pro 
- [workstation-pro-for windows10/11](https://drive.google.com/file/d/1OD2xdLzZ3kbNDV_EQteowo7IigEDP1-c/view?usp=sharing)

# Virtual Box
- https://download.virtualbox.org/virtualbox/7.0.18/VirtualBox-7.0.18-162988-Win.exe

# Kali Linux
- [kali Linux for => VMware](https://cdimage.kali.org/kali-2024.1/kali-linux-2024.1-vmware-amd64.7z)
- Download Kali linux VM file according to VM Application installed in win/Mac/Ubuntu.
- [Kali Linux for => VirtualBox](https://cdimage.kali.org/kali-2024.1/kali-linux-2024.1-virtualbox-amd64.7z)

# VMware key
- https://raw.githubusercontent.com/vaishnavucv/cybersecurity-note/main/vm-files/vm-key.txt

# 7-Zip
- https://github.com/vaishnavucv/cybersecurity-note/raw/main/vm-files/7z2301-x64.exe

# Kali Linux - login credentials 
- username: ```kali``` password: ```kali```

# Things that you need to do after install/Poweron Kali Linux
- [Todo-after-having-kali-linux.pdf]()
