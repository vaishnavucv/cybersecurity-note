Techmaghi soc lab dashboard
###
```url
https://20.193.141.173/app/wazuh#/
```

username:password please refer the video 

#### Note 🗒 :
```url
https://documentation.wazuh.com/current/deployment-options/docker/wazuh-container.html
```
