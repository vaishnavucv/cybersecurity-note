# cybersecurity-note
youtube videos
1. [Installing VMware Workstation 17 Pro in windows 10/11 ](https://youtu.be/v-dVKGmHzE0)
2. soon..!
